package com.tecmis.dto;

public class ManageSubject {



}
