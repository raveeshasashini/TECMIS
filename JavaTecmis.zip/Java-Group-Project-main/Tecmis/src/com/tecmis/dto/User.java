package com.tecmis.dto;

public class User {
    public String getUserAccountType() {
        return userAccountType;
    }

    public void setUserAccountType(String userAccountType) {
        this.userAccountType = userAccountType;
    }

    protected String userAccountType;

}

