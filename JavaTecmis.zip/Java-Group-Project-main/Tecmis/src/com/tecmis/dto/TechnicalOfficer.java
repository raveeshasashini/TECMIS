package com.tecmis.dto;

public class TechnicalOfficer {

        private String ID;
        private String username;
        private String password;
        private String Fname;
        private String Lname;
        private String Mobile;
        private String Address;
        private String Age;
        private String Email;
        private String DOM;
        private String Gender;
        private String T_Dep_ID;

        public String getID() {
            return ID;
        }

        public void setID(String ID) {
            this.ID = ID;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getFname() {
            return Fname;
        }

        public void setFname(String fname) {
            Fname = fname;
        }

        public String getLname() {
            return Lname;
        }

        public void setLname(String lname) {
            Lname = lname;
        }

        public String getMobile() {
            return Mobile;
        }

        public void setMobile(String mobile) {
            Mobile = mobile;
        }

        public String getAddress() {
            return Address;
        }

        public void setAddress(String address) {
            Address = address;
        }

        public String getAge() {
            return Age;
        }

        public void setAge(String age) {
            Age = age;
        }

        public String getEmail() {
            return Email;
        }

        public void setEmail(String email) {
            Email = email;
        }

        public String getDOM() {
            return DOM;
        }

        public void setDOM(String DOM) {
            this.DOM = DOM;
        }

        public String getGender() {
            return Gender;
        }

        public void setGender(String gender) {
            Gender = gender;
        }

        public String getT_Dep_ID() {
            return T_Dep_ID;
        }

        public void setT_Dep_ID(String t_Dep_ID) {
            T_Dep_ID = t_Dep_ID;
        }
    }


