package com.tecmis;

import com.tecmis.ui.LoginForm;

public class Main {
    public static void main(String[] args) {
        LoginForm loginForm = new LoginForm();

    }
}
