package com.tecmis.database;

public interface ReadBulkUsersInterface {
}
