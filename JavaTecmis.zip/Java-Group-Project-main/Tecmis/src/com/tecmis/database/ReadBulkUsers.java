package com.tecmis.database;

public class ReadBulkUsers {
}
