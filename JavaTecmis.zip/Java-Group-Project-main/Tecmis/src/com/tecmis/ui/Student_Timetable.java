package com.tecmis.ui;

import javax.swing.*;

public class Student_Timetable {
    private JLabel THeader;
    private JLabel lbl1;
    private JButton downloadButton1;
    private JLabel lbl2;
    private JButton downloadButton2;
    private JLabel lbl3;
    private JButton downloadButton3;
    private JLabel lbl4;
    private JButton downloadButton4;
}
