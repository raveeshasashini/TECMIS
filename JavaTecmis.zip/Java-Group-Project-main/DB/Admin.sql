INSERT INTO u812963415_javag2.Admin (ID, username, password, Fname, Lname, Mobile, Address, Age, Email, DOM, Gender, Admin_role) VALUES ('Admin/001', 'admin001', 'p1YZs9ZbJ2ArGj+WRS1akA==', 'Kasun', 'Fernando', '0771234567', '198 Street, Josephs Street, Colombo, Colombo', 30, 'Kasun@fot.ruh.ac.lk', '1990-12-10', 'M', 'admin');

