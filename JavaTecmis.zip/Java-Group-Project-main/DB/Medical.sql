INSERT INTO u812963415_javag2.Medical (Medical_ID, Stu_ID, Course_ID, DATE, Type, Hours, T_ID, Lecture_ID) VALUES ('M0001', 'TG/2020/002', 'ICT2142', '2023-02-05', 'Theory', '2', null, null);
