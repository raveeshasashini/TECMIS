INSERT INTO u812963415_javag2.Course (Course_ID, Course_Name, Credit) VALUES ('ICT01', 'Data Structures And Algorithms', 3);
INSERT INTO u812963415_javag2.Course (Course_ID, Course_Name, Credit) VALUES ('ICT02', 'Computer Network', 3);
INSERT INTO u812963415_javag2.Course (Course_ID, Course_Name, Credit) VALUES ('ICT03', 'Object Oriented Programming', 3);
INSERT INTO u812963415_javag2.Course (Course_ID, Course_Name, Credit) VALUES ('ICT04', 'Object Oriented Analysis and D', 2);
INSERT INTO u812963415_javag2.Course (Course_ID, Course_Name, Credit) VALUES ('ICT05', 'E-Commerce', 2);
INSERT INTO u812963415_javag2.Course (Course_ID, Course_Name, Credit) VALUES ('ICT06', 'English', 2);
