INSERT INTO u812963415_javag2.Department (Dep_ID, Dep_Name) VALUES ('depBST', 'Bio System Technology');
INSERT INTO u812963415_javag2.Department (Dep_ID, Dep_Name) VALUES ('depET', 'Engineering Technology');
INSERT INTO u812963415_javag2.Department (Dep_ID, Dep_Name) VALUES ('depICT', 'Information & Communication Technology');
INSERT INTO u812963415_javag2.Department (Dep_ID, Dep_Name) VALUES ('depTMS', 'Multidisciplinary Studies');
